#!/usr/bin/env python3
"""Validator for the PTDA lineage candidate XML (v2.0).

Checks, each reported PASS or FAIL. Exit status is 1 if any check fails.
    1. XSD: runs `xmllint --noout --schema` (libxml2). Missing xmllint is a FAIL, not a skip.
    2. Source: SHA-256 and byte size of --source match sourceManifest.
    3. IDs: every id is unique; every IDREF/ref points at an existing id.
    4. Claims: subject != object, reviewStatus is pending, at least one evidenceRef.
    5. Locators: each evidence unit is re-derived from the source file by an independent walk
       (item xml:id, raw text between rawStart/rawEnd, quote equals the non-space form of the
       raw snippet, and the quote occurs in the item body text).
    6. No DILA identifiers appear in the output.

Usage: python3 -I scripts/validate_package.py --source SRC.xml --output OUT.xml --schema XSD
"""
import argparse
import hashlib
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

TEI = "{http://www.tei-c.org/ns/1.0}"
XML_ID = "{http://www.w3.org/XML/1998/namespace}id"
NS = "{urn:ptda:research:lineage:1}"


class Report:
    def __init__(self):
        self.failures = []

    def check(self, name, ok, detail=""):
        status = "PASS" if ok else "FAIL"
        print(f"[{status}] {name}" + (f" -- {detail}" if detail else ""))
        if not ok:
            self.failures.append(name)


def check_xsd(rep, out_path, schema_path):
    xmllint = shutil.which("xmllint")
    if not xmllint:
        rep.check("XSD validation", False, "xmllint not found (install libxml2 utilities)")
        return
    proc = subprocess.run([xmllint, "--noout", "--schema", schema_path, out_path],
                          capture_output=True, text=True)
    detail = (proc.stderr or proc.stdout).strip().splitlines()
    rep.check("XSD validation (xmllint)", proc.returncode == 0,
              detail[-1] if detail else "validates")


def source_walk(item):
    """Independent re-derivation of an item's body text: text nodes outside <note>, as raw chars."""
    out = []

    def walk(elem):
        if elem.tag == f"{TEI}note":
            return
        out.append(elem.text or "")
        for child in elem:
            walk(child)
            out.append(child.tail or "")

    walk(item)
    return "".join(out)


def find_item(root, xml_id):
    for el in root.iter(f"{TEI}item"):
        if el.get(XML_ID) == xml_id:
            return el
    return None


def strip_ws(s):
    return re.sub(r"\s+", "", s)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--schema", required=True)
    args = ap.parse_args(argv)
    rep = Report()

    check_xsd(rep, args.output, args.schema)

    with open(args.source, "rb") as f:
        raw_src = f.read()
    out_root = ET.parse(args.output).getroot()
    src_root = ET.fromstring(raw_src)

    man = out_root.find(f"{NS}sourceManifest")
    sha = hashlib.sha256(raw_src).hexdigest()
    rep.check("source SHA-256 matches sourceManifest",
              man.findtext(f"{NS}sha256") == sha, sha)
    rep.check("source byte size matches sourceManifest",
              int(man.findtext(f"{NS}byteSize")) == len(raw_src), f"{len(raw_src)} bytes")

    # IDs
    ids = [el.get("id") for el in out_root.iter() if el.get("id") is not None]
    dup = sorted({i for i in ids if ids.count(i) > 1})
    rep.check("no duplicate ids", not dup, ", ".join(dup[:5]))
    idset = set(ids)
    refs = [el.get("ref") for el in out_root.iter() if el.get("ref") is not None]
    missing = sorted({r for r in refs if r not in idset})
    rep.check("every ref resolves to an existing id", not missing, ", ".join(missing[:5]))

    # Claims
    claims = list(out_root.iter(f"{NS}relationClaim"))
    bad_self = [c.get("id") for c in claims
                if c.find(f"{NS}subjectPersonRef").get("ref") == c.find(f"{NS}objectPersonRef").get("ref")]
    rep.check("no self-loop claims", not bad_self, ", ".join(bad_self))
    not_pending = [c.get("id") for c in claims if c.findtext(f"{NS}reviewStatus") != "pending"]
    rep.check("all claims reviewStatus=pending", not not_pending, ", ".join(not_pending))
    no_ev = [c.get("id") for c in claims if not c.findall(f"{NS}evidenceRef")]
    rep.check("every claim cites evidence", not no_ev, ", ".join(no_ev))

    # Locators
    bad = []
    evs = list(out_root.iter(f"{NS}evidenceUnit"))
    for ev in evs:
        item_id = ev.findtext(f"{NS}itemXmlId")
        item = find_item(src_root, item_id)
        if item is None:
            bad.append(f"{ev.get('id')}: item {item_id} not in source")
            continue
        body = source_walk(item)
        rs, re_ = int(ev.findtext(f"{NS}rawStart")), int(ev.findtext(f"{NS}rawEnd"))
        snippet = ev.findtext(f"{NS}rawSnippet")
        if body[rs:re_] != snippet:
            bad.append(f"{ev.get('id')}: rawSnippet does not match source[{rs}:{re_}]")
            continue
        quote = ev.findtext(f"{NS}normalizedQuote")
        if quote != strip_ws(snippet):
            bad.append(f"{ev.get('id')}: normalizedQuote is not the non-space form of rawSnippet")
            continue
        if quote not in strip_ws(body):
            bad.append(f"{ev.get('id')}: normalizedQuote not found in item body")
    rep.check("evidence locators and normalized quotes match the source text", not bad, "; ".join(bad[:3]))

    # A pronoun resolution must name the claim's object as antecedent (proposal only).
    pron_bad = []
    for c in claims:
        pr = c.find(f"{NS}pronounResolution")
        if pr is not None and pr.find(f"{NS}antecedentRef").get("ref") != c.find(f"{NS}objectPersonRef").get("ref"):
            pron_bad.append(c.get("id"))
    rep.check("pronoun antecedents equal the claim object", not pron_bad, ", ".join(pron_bad))

    # Output must not carry DILA identifiers
    with open(args.output, encoding="utf-8") as f:
        text = f.read()
    rep.check("no DILA identifiers in output", re.search(r"DILA", text, re.I) is None)

    print()
    if rep.failures:
        print(f"RESULT: FAIL ({len(rep.failures)} check(s))")
        return 1
    print("RESULT: PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
