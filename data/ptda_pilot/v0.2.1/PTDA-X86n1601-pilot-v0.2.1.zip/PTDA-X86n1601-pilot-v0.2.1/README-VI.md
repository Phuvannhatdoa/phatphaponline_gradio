# PTDA pilot v0.2.1: 禪燈世譜 (CBETA X86n1601), mục 三十三祖世系圖

Trạng thái: **candidate / pending**. Gói này là dữ liệu ứng viên để QA độc lập. Không có claim nào được xác nhận lịch sử. Không có dữ liệu nào được import vào DB, API hay production.

v0.2.1 áp dụng quyết định QA trên v0.2 (xem `manual/qa-decisions-v0.2.1.json`, `reports/changelog-v0.1-to-v0.2.md`). Kiểm tay từng claim ở `reports/manual-review-16-claims.md`.

## 1. Phạm vi thực tế

- Chỉ xử lý mục **三十三祖世系圖** trong quyển 001 (danh sách 34 mục, chỉ số 0–33, từ 釋迦牟尼佛 đến 慧能).
- **Chưa xử lý:** phần còn lại của quyển 001, quyển 002–009.
- Không dùng sơ đồ hay bảng. Mục này là danh sách văn bản, không có cấu trúc bảng được mã hóa.
- Không gán DILA ID. Không tính số đời PTDA. Nhãn đời của nguồn (始祖, 第一祖, …) được giữ nguyên trong `generationLabels`.

## 2. Kết quả

| Mục | Số lượng |
|---|---|
| Nhân vật (persons) | 34 |
| Mention | 60 |
| Đơn vị chứng cứ (evidenceUnit) | 16 |
| Claim quan hệ (relationClaim) | 16 (15 từ extractor, 1 ứng viên đại từ từ QA) |
| Trường hợp chưa giải quyết (unresolvedCases) | 40 (21 gợi ý tên rút gọn, 19 đại từ/ngữ cảnh) |

Trong 16 claim: 3 có chiều `unknown` kèm ứng viên (8→7, 11→12, 27→28), 1 là ứng viên đại từ (12→13, bước giải đại từ được ghi, chưa accepted), 12 còn lại có chiều theo câu. Tất cả `pending`. Bảng đối soát: `reports/claim-reconciliation-v0.1-to-v0.2.md`. Bảng claim: `reports/claims-v0.2.md`.

Các cặp 17→18 và 31→32 không có cạnh. Mục 31 không có động từ truyền pháp. Mục 17 có 傳大法要 nhưng người nhận không xác định được theo luật, nên được ghi unresolved. Không có cạnh nào được tạo từ thứ tự danh sách.

## 3. Cấu trúc gói

```
PTDA-X86n1601-pilot-v0.2/
  README-VI.md                 tài liệu này
  manual/qa-decisions-v0.2.1.json  quyết định QA (áp dụng bằng --decisions)
  requirements.txt             dependency và phiên bản đã kiểm
  SHA256SUMS.txt               hash mọi file trong gói
  source/X86n1601.source.xml   nguồn, khóa theo byte (796,393 byte)
  derived/X86n1601.pilot.claims.xml  đầu ra (namespace urn:ptda:research:lineage:1)
  schema/ptda-lineage-v1.xsd   XSD phiên bản 2.1
  scripts/extract_lineage.py   extractor (CLI)
  scripts/validate_package.py  validator (CLI)
  tests/test_extraction.py     30 test
  tests/test-results.txt       log chạy test
  manifests/source-manifest.json  nguồn, hash, commit, quyền
  manifests/run-manifest.json     số liệu và thời gian chạy (chỉ ở file này)
  reports/                     báo cáo cấu trúc, luật, đối soát, kiểm tay 16 claim, unresolved, quyền, changelog
```

## 4. Dependency và phiên bản đã kiểm

| Thành phần | Phiên bản đã kiểm | Ghi chú |
|---|---|---|
| Python | 3.11.15 | Chỉ dùng thư viện chuẩn: xml.etree, hashlib, re, subprocess, unittest |
| xmllint (libxml2) | libxml2 2.9.14 (`xmllint` báo 20914) | Bắt buộc cho bước XSD. Không có xmllint thì validator báo FAIL, không bỏ qua |
| Thư viện Python ngoài | không có | Không cần pip |

**Windows:** cài libxml2 bằng một trong các cách sau: gói `libxml2` của MSYS2 (`pacman -S mingw-w64-x86_64-libxml2`, lấy `xmllint.exe`), hoặc bản xmllint Windows từ libxml2 binary. Đặt `xmllint.exe` vào PATH.
**Linux (Debian/Ubuntu):** `sudo apt install libxml2-utils` (cung cấp `xmllint`).

## 5. Lệnh chạy

Chạy từ thư mục gốc của gói. Dùng `-I` để không có module cục bộ nào đè lên thư viện chuẩn.

**Linux / macOS:**
```bash
python3 -I scripts/extract_lineage.py \
  --source source/X86n1601.source.xml \
  --output derived/X86n1601.pilot.claims.xml \
  --schema schema/ptda-lineage-v1.xsd \
  --decisions manual/qa-decisions-v0.2.1.json \
  --run-manifest manifests/run-manifest.json

python3 -I scripts/validate_package.py \
  --source source/X86n1601.source.xml \
  --output derived/X86n1601.pilot.claims.xml \
  --schema schema/ptda-lineage-v1.xsd

python3 -I -m unittest discover -s tests -v
```

**Windows (PowerShell):**
```powershell
py -3.11 -I scripts\extract_lineage.py --source source\X86n1601.source.xml --output derived\X86n1601.pilot.claims.xml --schema schema\ptda-lineage-v1.xsd --decisions manual\qa-decisions-v0.2.1.json --run-manifest manifests\run-manifest.json
py -3.11 -I scripts\validate_package.py --source source\X86n1601.source.xml --output derived\X86n1601.pilot.claims.xml --schema schema\ptda-lineage-v1.xsd
py -3.11 -I -m unittest discover -s tests -v
```

Đường dẫn không được hardcode. Extractor đọc `--source` và ghi `--output`. Không ghi đè `source/`. Nếu `--output` đã tồn tại, extractor ghi lại file đó; hãy đổi tên trước khi chạy lại nếu cần giữ bản cũ.

Replay: cùng nguồn và cùng luật cho ra file claims giống hệt từng byte. Thời gian chạy chỉ nằm trong `run-manifest.json`.

## 6. Kiểm tra đã chạy

- XSD: `xmllint --noout --schema` trên output. Kết quả: validates.
- Validator: 11 kiểm tra (XSD, hash nguồn, kích thước nguồn, ID trùng, ref hỏng, self-loop, reviewStatus, mỗi claim có chứng cứ, locator và chuỗi chuẩn hóa so với nguồn, antecedent của đại từ, không có DILA). Kết quả: PASS.
- Test: 30 test, gồm 11 test luật trên fixture tổng hợp, 6 test trên nguồn thật, 6 test quyết định QA, 7 test đột biến validator. Kết quả: OK (xem `tests/test-results.txt`).

Các fixture trong `tests/test_extraction.py` là văn bản tổng hợp, không phải CBETA. Chúng được ghi nhãn FIXTURE trong từng test.

## 7. Giới hạn

- Đại từ 之 ở mục 12: 12→13 chỉ là ứng viên với `pronounResolution status=proposed`. Chưa được chấp nhận.
- Mẫu 「得X付法」 có hai cách đọc. Các claim 8→7, 11→12, 27→28 có chiều `unknown`. Claim 30→31 giữ theo cách đọc của câu, vẫn `pending`.
- Quyết định QA ở `manual/` đổi chiều và thêm ứng viên. Không phải xác nhận lịch sử.
- Cờ `short_or_variant_name` là gợi ý khớp chuỗi con, nhiều dương tính giả. Các cặp tên rút gọn (優波尊者, 龍樹, 闍夜尊者, 難提尊者, 夜奢) và dị bản 不如密多/不如蜜多 chưa được liên kết. Xem `reports/manual-review-16-claims.md`.
- Cờ `short_or_variant_name` là gợi ý khớp chuỗi con, nhiều dương tính giả. Không dùng làm bằng chứng.
- Thọ giới, thế độ, đệ tử không có loại quan hệ riêng trong v0.2.
- Kiểm tay 16 claim đã có trong `reports/manual-review-16-claims.md`. Không đối chiếu được ảnh trang bản in trong phiên này. Việc đó là của QA.

## 8. Quyền

Header CBETA ghi: "Available for non-commercial use when distributed with this header intact." Đây là điều kiện do nguồn nêu, được trích nguyên văn. Gói không áp CC license text lên dữ liệu dẫn xuất, scripts hay XSD. Trạng thái quyền của từng file là `pending-review`. v0.1 có kết luận CC BY-NC-SA 4.0 nhưng không có chứng cứ đủ để giữ kết luận đó. Xem `reports/rights-notice.md`.

## 9. Nguồn đã khóa

- SHA-256: `60a282bf78795048395dfdb6ab2ac0d7912bbd6b527338d9664f58994e84f178`
- Git: repo `Phuvannhatdoa/phatphaponline_gradio`, branch `truyen-dang-the-pho-clean`, commit `a0d504c273cee18d09adfed2d601208cd3d532e4`, blob `ee2e8ce6e3fca8eeb718b4a4fe81ca30cee58cd5`.
- Đối chiếu với bản CBETA upstream do người gửi kiểm tra. Phiên làm việc này không tải lại được bản upstream vì proxy chặn `raw.githubusercontent.com`.

Chi tiết trong `manifests/source-manifest.json`.
