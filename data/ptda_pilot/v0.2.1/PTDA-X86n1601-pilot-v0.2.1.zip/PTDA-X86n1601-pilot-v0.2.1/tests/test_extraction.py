#!/usr/bin/env python3
"""Tests for the PTDA lineage pilot v0.2.

Two kinds of input are used, and they are labelled in each test:
  * FIXTURE: small synthetic TEI snippets written for these tests. Their Han text is
    invented to exercise one rule each. They are NOT CBETA text.
  * REAL: the CBETA X86n1601 source in source/ and the extractor output built from it.

Run from the package root:  python3 -I -m unittest discover -s tests -v
Mutation tests run the validator and expect FAIL; a FAIL verdict is the passing outcome there.
"""
import contextlib
import hashlib
import io
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(PKG, "scripts"))
import extract_lineage as E  # noqa: E402

SRC = os.path.join(PKG, "source", "X86n1601.source.xml")
SCHEMA = os.path.join(PKG, "schema", "ptda-lineage-v1.xsd")
VALIDATOR = os.path.join(PKG, "scripts", "validate_package.py")
NS = "{urn:ptda:research:lineage:1}"

HEAD = ('<TEI xmlns="http://www.tei-c.org/ns/1.0" xmlns:cb="http://www.cbeta.org/ns/1.0">'
        '<teiHeader/><text><body><cb:div><cb:mulu>三十三祖世系圖</cb:mulu>'
        '<list rend="no-marker">')
TAIL = '</list></cb:div></body></text></TEI>'


def fixture(items_xml):
    """Wrap FIXTURE items in the section structure the extractor looks for."""
    return ET.fromstring(HEAD + items_xml + TAIL)


def run_fixture(items_xml):
    root = fixture(items_xml)
    items = E.load_items(root)
    claims, unresolved, names = E.extract(items, "fixture")
    return items, claims, unresolved


def item(n, label, name, body):
    """FIXTURE item: label note, name on its own line, body paragraph."""
    return (f'<item xml:id="fx{n:02d}"><note>{label}</note>{name}\n'
            f'<p xml:id="fxp{n:02d}">{body}</p></item>')


def kinds(unresolved):
    return sorted(u["kind"] for u in unresolved)


class FixtureRules(unittest.TestCase):
    """FIXTURE: each test isolates one rule."""

    def test_positive_direct_transmission_same_clause(self):
        # FIXTURE: 甲 gives to 乙 with the receiver named in the same clause.
        items, claims, _ = run_fixture(
            item(0, "始祖", "甲", "甲付乙。") + item(1, "第一祖", "乙", "乙無事。"))
        self.assertIn((0, 1), claims)
        self.assertEqual(claims[(0, 1)]["direction"], "subject_to_object")
        self.assertEqual(claims[(0, 1)]["rules"], ["R1"])

    def test_negation_creates_no_edge(self):
        # FIXTURE: 未付 is negated; no edge may be asserted and the case is recorded.
        items, claims, unresolved = run_fixture(
            item(0, "始祖", "甲", "甲未付乙。") + item(1, "第一祖", "乙", "乙無事。"))
        self.assertEqual(claims, {})
        self.assertIn("negated_transmission", kinds(unresolved))

    def test_mention_without_transmission_verb(self):
        # FIXTURE: 甲 and 乙 appear together with no transmission verb: mention only.
        items, claims, unresolved = run_fixture(
            item(0, "始祖", "甲", "甲與乙同參。") + item(1, "第一祖", "乙", "乙無事。"))
        self.assertEqual(claims, {})

    def test_ordination_is_not_transmission(self):
        # FIXTURE: 受戒 (ordination) is not a dharma-transmission verb in this rule set.
        items, claims, _ = run_fixture(
            item(0, "始祖", "甲", "甲於乙前受戒。") + item(1, "第一祖", "乙", "乙無事。"))
        self.assertEqual(claims, {})

    def test_receipt_marker_sets_direction_from_current_item(self):
        # FIXTURE: 遇乙 in one clause, 付以法 in the next: the current item gives to 乙 (R3).
        items, claims, _ = run_fixture(
            item(0, "始祖", "甲", "遇乙，付以法。") + item(1, "第一祖", "乙", "乙無事。"))
        self.assertIn((0, 1), claims)
        self.assertEqual(claims[(0, 1)]["rules"], ["R3"])

    def test_reversed_direction_is_flagged_not_forced(self):
        # FIXTURE: 乙 gives to 甲 inside 甲's entry, although 甲 is listed first.
        items, claims, _ = run_fixture(
            item(0, "始祖", "甲", "乙付以正法。") + item(1, "第一祖", "乙", "乙無事。"))
        self.assertIn((1, 0), claims)
        self.assertNotIn((0, 1), claims)
        self.assertIn("text_direction_differs_from_list_order", claims[(1, 0)]["flags"])

    def test_variant_character_is_not_linked(self):
        # FIXTURE: 密 vs 蜜 is a variant form; without a source-declared alias it must not link.
        items, claims, unresolved = run_fixture(
            item(0, "始祖", "甲", "甲付婆須密多。") + item(1, "第一祖", "婆須蜜多", "乙無事。"))
        self.assertEqual(claims, {})

    def test_short_name_is_recorded_not_linked(self):
        # FIXTURE: 難提 is a suffix of 佛陀難提; the short form must not create an edge.
        items, claims, unresolved = run_fixture(
            item(0, "始祖", "甲", "甲付難提。") + item(1, "第一祖", "佛陀難提", "乙無事。"))
        self.assertEqual(claims, {})
        self.assertIn("short_or_variant_name", kinds(unresolved))

    def test_several_relations_from_one_entry(self):
        # FIXTURE: one entry can give to more than one named person; no early break.
        items, claims, _ = run_fixture(
            item(0, "始祖", "甲", "甲付乙，又付丙。") + item(1, "第一祖", "乙", "乙無事。")
            + item(2, "第二祖", "丙", "丙無事。"))
        self.assertIn((0, 1), claims)
        self.assertIn((0, 2), claims)

    def test_no_evidence_no_claim(self):
        # FIXTURE: no transmission sentence at all: zero claims.
        items, claims, _ = run_fixture(
            item(0, "始祖", "甲", "甲無事。") + item(1, "第一祖", "乙", "乙無事。"))
        self.assertEqual(claims, {})

    def test_list_order_alone_creates_no_edge(self):
        # FIXTURE: 甲 is directly before 乙 in the list, and there is no transmission text.
        items, claims, _ = run_fixture(
            item(0, "始祖", "甲", "甲無事。") + item(1, "第一祖", "乙", "乙無事。"))
        self.assertNotIn((0, 1), claims)


class RealSource(unittest.TestCase):
    """REAL: CBETA X86n1601 section 三十三祖世系圖 as shipped in source/."""

    @classmethod
    def setUpClass(cls):
        with open(SRC, "rb") as f:
            cls.raw = f.read()
        cls.sha = hashlib.sha256(cls.raw).hexdigest()
        root = ET.fromstring(cls.raw)
        cls.items = E.load_items(root)
        cls.claims, cls.unresolved, _ = E.extract(cls.items, cls.sha)

    def test_source_hash_is_the_locked_value(self):
        self.assertEqual(self.sha, "60a282bf78795048395dfdb6ab2ac0d7912bbd6b527338d9664f58994e84f178")
        self.assertEqual(len(self.raw), 796393)

    def test_thirty_four_entries(self):
        self.assertEqual(len(self.items), 34)

    def test_known_relations_present_with_direction(self):
        # REAL: explicit sentences in the source.
        self.assertIn((0, 1), self.claims)    # 乃以大法印付囑摩訶迦葉
        self.assertIn((2, 3), self.claims)    # 乃以法付其弟子商那和修
        self.assertIn((3, 4), self.claims)    # 後以法付優波毱多
        self.assertIn((8, 9), self.claims)    # 以法付伏駄密多
        self.assertIn((24, 25), self.claims)  # 以法授婆舍斯多
        self.assertIn((26, 27), self.claims)  # 以正法眼藏付般若多羅

    def test_text_reversal_flagged_for_items_7_and_8(self):
        # REAL: item 7 text says 佛陀難提 gives the dharma; list order would suggest 7→8.
        self.assertIn((8, 7), self.claims)
        self.assertNotIn((7, 8), self.claims)
        self.assertIn("text_direction_differs_from_list_order", self.claims[(8, 7)]["flags"])

    def test_no_claim_is_forced_without_text(self):
        # REAL: 17→18 and 31→32 have no transmission sentence in the entry text.
        self.assertNotIn((17, 18), self.claims)
        self.assertNotIn((31, 32), self.claims)

    def test_replay_is_identical(self):
        # REAL: same source and same rules give the same claims XML byte for byte.
        out1, out2 = tempfile.mkdtemp(), tempfile.mkdtemp()
        try:
            for d in (out1, out2):
                with contextlib.redirect_stdout(io.StringIO()):
                    E.main(["--source", SRC, "--output", os.path.join(d, "c.xml"), "--schema", SCHEMA])
            with open(os.path.join(out1, "c.xml"), "rb") as a, open(os.path.join(out2, "c.xml"), "rb") as b:
                self.assertEqual(a.read(), b.read())
        finally:
            shutil.rmtree(out1)
            shutil.rmtree(out2)


class QaDecisions(unittest.TestCase):
    """REAL: reviewer decisions from manual/qa-decisions-v0.2.1.json are applied and traceable."""

    DECISIONS = os.path.join(PKG, "manual", "qa-decisions-v0.2.1.json")

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.out = os.path.join(cls.tmp, "d.xml")
        with contextlib.redirect_stdout(io.StringIO()):
            E.main(["--source", SRC, "--output", cls.out, "--schema", SCHEMA, "--decisions", cls.DECISIONS])
        cls.root = ET.parse(cls.out).getroot()
        cls.ids = {p.get("id"): p.findtext(f"{NS}sourceItemXmlId")
                   for p in cls.root.iter(f"{NS}person")}

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp)

    def test_claim_8_to_7_direction_unknown_with_candidate(self):
        # QA-01: direction is not normalized; the reading 8->7 is kept as a candidate.
        c = self.claim_by_items("itemX86p0321a5501", "itemX86p0321a4901")
        self.assertEqual(c.findtext(f"{NS}directionStatus"), "unknown")
        self.assertEqual(c.findtext(f"{NS}candidateDirection"), "subject_to_object")
        self.assertEqual(c.findtext(f"{NS}decisionRef"), "QA-01")

    def test_claim_27_to_28_direction_unknown_with_candidate(self):
        # QA-02: the 得X付法 sentence is read on its own, not by a general rule.
        c = self.claim_by_items("itemX86p0323a1301", "itemX86p0323a1901")
        self.assertEqual(c.findtext(f"{NS}directionStatus"), "unknown")
        self.assertEqual(c.findtext(f"{NS}decisionRef"), "QA-02")

    def test_claim_30_to_31_kept_as_per_sentence_reading(self):
        # QA-03: direction stays subject_to_object; still pending.
        c = self.claim_by_items("itemX86p0323a4701", "itemX86p0323a5601")
        self.assertEqual(c.findtext(f"{NS}directionStatus"), "subject_to_object")
        self.assertEqual(c.findtext(f"{NS}reviewStatus"), "pending")

    def test_pronoun_candidate_12_to_13_is_proposed_not_accepted(self):
        # QA-05: 之 -> 迦毗摩羅 is a proposal with its resolution steps recorded.
        c = self.claim_by_items("itemX86p0321a7901", "itemX86p0322a0101")
        pr = c.find(f"{NS}pronounResolution")
        self.assertEqual(pr.findtext(f"{NS}pronoun"), "之")
        self.assertEqual(pr.findtext(f"{NS}status"), "proposed")
        self.assertEqual(c.findtext(f"{NS}reviewStatus"), "pending")

    def test_total_claims_with_decisions(self):
        self.assertEqual(len(list(self.root.iter(f"{NS}relationClaim"))), 16)

    def test_xsd_rejects_invalid_candidate_direction(self):
        # A candidate direction outside the enumeration must fail the schema.
        with open(self.out, encoding="utf-8") as f:
            text = f.read()
        bad = text.replace("<candidateDirection>subject_to_object", "<candidateDirection>forced", 1)
        path = os.path.join(self.tmp, "bad.xml")
        with open(path, "w", encoding="utf-8") as f:
            f.write(bad)
        proc = subprocess.run(["xmllint", "--noout", "--schema", SCHEMA, path],
                              capture_output=True, text=True)
        self.assertNotEqual(proc.returncode, 0)

    def claim_by_items(self, subj_xml, obj_xml):
        for c in self.root.iter(f"{NS}relationClaim"):
            s = self.ids[c.find(f"{NS}subjectPersonRef").get("ref")]
            o = self.ids[c.find(f"{NS}objectPersonRef").get("ref")]
            if (s, o) == (subj_xml, obj_xml):
                return c
        self.fail(f"no claim {subj_xml} -> {obj_xml}")


class ValidatorOnRealOutput(unittest.TestCase):
    """REAL: validator must PASS the clean output and FAIL each broken copy."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.clean = os.path.join(cls.tmp, "clean.xml")
        with contextlib.redirect_stdout(io.StringIO()):
            E.main(["--source", SRC, "--output", cls.clean, "--schema", SCHEMA])
        with open(cls.clean, encoding="utf-8") as f:
            cls.text = f.read()

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp)

    def run_validator(self, xml_text, source=SRC):
        path = os.path.join(self.tmp, "case.xml")
        with open(path, "w", encoding="utf-8") as f:
            f.write(xml_text)
        proc = subprocess.run([sys.executable, "-I", VALIDATOR, "--source", source,
                               "--output", path, "--schema", SCHEMA],
                              capture_output=True, text=True)
        return proc.returncode, proc.stdout

    def test_clean_output_passes(self):
        code, out = self.run_validator(self.text)
        self.assertEqual(code, 0, out)
        self.assertIn("RESULT: PASS", out)

    def test_duplicate_id_fails(self):
        # MUTATION: second evidence unit reuses the first id.
        first = self.text.index('<evidenceUnit id="') + len('<evidenceUnit id="')
        end = self.text.index('"', first)
        rid = self.text[first:end]
        second = self.text.index('<evidenceUnit id="', end) + len('<evidenceUnit id="')
        mutated = self.text[:second] + rid + self.text[self.text.index('"', second):]
        code, out = self.run_validator(mutated)
        self.assertNotEqual(code, 0, out)

    def test_broken_evidence_ref_fails(self):
        # MUTATION: an evidenceRef points at a non-existent id.
        mutated = self.text.replace('<evidenceRef ref="', '<evidenceRef ref="EV-missing-', 1)
        code, out = self.run_validator(mutated)
        self.assertNotEqual(code, 0, out)

    def test_claim_without_evidence_fails_xsd(self):
        # MUTATION: remove every evidenceRef from the first claim. The XSD must reject it.
        start = self.text.index("<relationClaim ")
        end = self.text.index("</relationClaim>", start)
        block = self.text[start:end]
        cleaned = "\n".join(l for l in block.splitlines() if "<evidenceRef" not in l)
        mutated = self.text[:start] + cleaned + self.text[end:]
        code, out = self.run_validator(mutated)
        self.assertNotEqual(code, 0, out)
        self.assertIn("XSD validation", out)

    def test_changed_source_fails_hash(self):
        # MUTATION: validator is given a source file with one byte changed.
        changed = os.path.join(self.tmp, "changed.xml")
        with open(SRC, "rb") as f:
            data = bytearray(f.read())
        data[len(data) // 2] ^= 0x01
        with open(changed, "wb") as f:
            f.write(bytes(data))
        code, out = self.run_validator(self.text, source=changed)
        self.assertNotEqual(code, 0, out)
        self.assertIn("[FAIL] source SHA-256", out)

    def test_wrong_locator_fails(self):
        # MUTATION: rawSnippet is replaced with text that is not at that source position.
        mutated = self.text.replace("<rawSnippet>", "<rawSnippet>XX", 1)
        code, out = self.run_validator(mutated)
        self.assertNotEqual(code, 0, out)

    def test_quote_not_matching_snippet_fails(self):
        # MUTATION: normalizedQuote is changed so it no longer equals the non-space form of the snippet.
        start = self.text.index("<normalizedQuote>") + len("<normalizedQuote>")
        mutated = self.text[:start] + "鬼" + self.text[start:]
        code, out = self.run_validator(mutated)
        self.assertNotEqual(code, 0, out)


if __name__ == "__main__":
    unittest.main()
