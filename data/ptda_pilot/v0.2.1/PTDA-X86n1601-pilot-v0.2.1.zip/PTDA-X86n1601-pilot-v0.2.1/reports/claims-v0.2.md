# Bảng claim v0.2.1 (sinh từ derived/X86n1601.pilot.claims.xml)

Trạng thái: pending. `unknown` nghĩa là chưa xác định chiều; ứng viên ghi ở cột riêng. Kiểm tay chi tiết: `manual-review-16-claims.md`.

| Claim | Từ | Đến | Động từ (Hán nguồn) | Chiều | Ứng viên | Quyết định | Luật | Chứng cứ | Trang / dòng ed=X | normalizedQuote |
|---|---|---|---|---|---|---|---|---|---|---|
| RC-5853eb223039 | 0 釋迦牟尼佛 | 1 摩訶迦葉 | 付囑 | subject_to_object | - | - | R1 | 1 | 0320a 0320a22 | 乃以大法印付囑摩訶迦葉 |
| RC-96af990ee99f | 2 阿難尊者 | 3 商那和修 | 付 | subject_to_object | - | - | R1 | 1 | 0321a 0321a15 | 乃以法付其弟子商那和修 |
| RC-16a7c736bed6 | 3 商那和修 | 4 優波毱多 | 付 | subject_to_object | - | - | R1 | 1 | 0321a 0321a26 | 後以法付優波毱多 |
| RC-bae3b16dcbef | 5 提多迦 | 6 彌遮迦 | 付 | subject_to_object | - | - | R1 | 1 | 0321a 0321a41 | 後付彌遮迦 |
| RC-1aafe0d1f7b1 | 6 彌遮迦 | 7 婆須蜜 | 付以 | subject_to_object | - | - | R3 | 1 | 0321a 0321a47 | 遇婆須蜜，付以法 |
| RC-b7751e34d6d1 | 8 佛陀難提 | 7 婆須蜜 | 付以 | unknown | subject_to_object | QA-01 | R4 | 1 | 0321a 0321a52 | 佛陀難提付以正法 |
| RC-eec1bda360b3 | 8 佛陀難提 | 9 伏駄密多 | 付 | subject_to_object | - | - | R1 | 1 | 0321a 0321a59 | 以法付伏駄密多 |
| RC-c9a82d40ac11 | 11 富那夜奢 | 12 馬鳴大士 | 付 | unknown | subject_to_object | QA-04 | R3 | 1 | 0321a 0321a75 | 得馬鳴大士付正法眼藏 |
| RC-6d067420c17c | 12 馬鳴大士 | 13 迦毗摩羅 | 付 | subject_to_object | - | QA-05 | R5 | 1 | 0321a 0321a82 | 攝伏迦毗摩羅為弟子，遂以法付之 |
| RC-cd3fe29462b1 | 14 龍樹尊者 | 15 迦那提婆 | 付 | subject_to_object | - | - | R1 | 1 | 0322a 0322a10 | 乃以其法印付迦那提婆 |
| RC-cb02aebecc9a | 24 師子尊者 | 25 婆舍斯多 | 授 | subject_to_object | - | - | R1 | 1 | 0322a 0322a69 | 以法授婆舍斯多 |
| RC-54484d3c8d5b | 25 婆舍斯多 | 26 不如密多 | 付 | subject_to_object | - | - | R2 | 1 | 0323a 0323a09 | 從婆舍斯多出家付法 |
| RC-a151d1f6e0e2 | 26 不如密多 | 27 般若多羅 | 付 | subject_to_object | - | - | R1 | 1 | 0323a 0323a11 | 以正法眼藏付般若多羅 |
| RC-639d023a3086 | 27 般若多羅 | 28 菩提達磨 | 付 | unknown | subject_to_object | QA-02 | R2+R3 | 2 | 0323a 0323a17 | 得菩提達磨付法 |
| RC-2eae0012e122 | 29 慧可 | 30 僧璨 | 傳法 | subject_to_object | - | - | R1 | 1 | 0323a 0323a40 | 後傳法僧璨 |
| RC-c1ae9cef4a86 | 30 僧璨 | 31 道信 | 付以 | subject_to_object | subject_to_object | QA-03 | R3 | 1 | 0323a 0323a51 | 後得道信，付以法眼 |
