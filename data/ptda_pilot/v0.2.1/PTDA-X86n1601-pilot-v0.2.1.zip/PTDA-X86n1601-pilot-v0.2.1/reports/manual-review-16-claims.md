# Kiểm tay 16 claim ứng viên (v0.2.1)

Phạm vi: mục 三十三祖世系圖 của X86n1601. Mọi dòng `pending`. Không dòng nào là xác nhận lịch sử.
Locator: trang và dòng ed=X. Chỉ số mục: 0 = 釋迦牟尼佛, 33 = 慧能.
Loại quan hệ: mọi claim là `dharma_transmission` ở mức ứng viên. Không có claim thọ giới hay học tập.

Cột "Kiểm tay" là kết luận của người kiểm đọc câu chữ trong gói. Đó không phải kết luận QA.

| Claim | Cặp (chỉ số) | Chiều hiện tại | Câu chữ nguồn | Locator | Đọc câu | Kiểm tay | Việc cần QA |
|---|---|---|---|---|---|---|---|
| RC-5853eb223039 | 0 釋迦牟尼佛 → 1 摩訶迦葉 | subject_to_object | 乃以大法印付囑摩訶迦葉 | 0320a22 | Phật trao pháp ấn cho Đại Ca Diếp. Chủ thể và đối tượng đều có tên trong câu. | Đủ căn cứ câu chữ. | Không |
| RC-96af990ee99f | 2 阿難尊者 → 3 商那和修 | subject_to_object | 乃以法付其弟子商那和修 | 0321a15 | A-nan trao pháp cho đệ tử là 商那和修. | Đủ căn cứ câu chữ. | Không |
| RC-16a7c736bed6 | 3 商那和修 → 4 優波毱多 | subject_to_object | 後以法付優波毱多 | 0321a26 | 商那和修 trao pháp cho 優波毱多. | Đủ căn cứ câu chữ. | Không |
| RC-bae3b16dcbef | 5 提多迦 → 6 彌遮迦 | subject_to_object | 後付彌遮迦 | 0321a41 | Chủ thể là 提多迦 ẩn trong bio của mục 5. Đối tượng được nêu trong câu. | Đúng nhưng dựa vào chủ thể ẩn của bio. | Nên xác nhận quy ước chủ thể ẩn. |
| RC-1aafe0d1f7b1 | 6 彌遮迦 → 7 婆須蜜 | subject_to_object | 遇婆須蜜，付以法 | 0321a47 | 彌遮迦 gặp 婆須蜜 rồi trao pháp. Chủ thể ẩn, đối tượng ở mệnh đề trước. | Hợp lý, cần xác nhận cách đọc mệnh đề 遇X, 付. | Xác nhận cách đọc 遇X, 付. |
| RC-b7751e34d6d1 | 8 佛陀難提 → 7 婆須蜜 | **unknown** (ứng viên 8→7) | 佛陀難提付以正法 | 0321a52 | Câu này nêu 佛陀難提 là người trao pháp. Mục 7 đặt trước mục 8 trong danh sách, nên có mâu thuẫn chiều. Văn bản mục 7 có 周定王世, cùng ngữ cảnh. | Mâu thuẫn chiều thật sự. Chưa đủ căn cứ kết luận lỗi nguồn hay lỗi trình bày. | QA-01: đối chiếu ảnh trang bản in và ngữ cảnh. |
| RC-eec1bda360b3 | 8 佛陀難提 → 9 伏駄密多 | subject_to_object | 於周景王世，以法付伏駄密多 | 0321a59 | 佛陀難提 trao pháp cho 伏駄密多. Mục 9 có thêm 難提尊者示其夙緣，付以法印 (tên rút gọn, chưa liên kết). | Đủ căn cứ câu chữ. | Không |
| RC-c9a82d40ac11 | 11 富那夜奢 → 12 馬鳴大士 | **unknown** (ứng viên) | 遊化波羅奈國，得馬鳴大士付正法眼藏 | 0321a75 | Cấu trúc 得X付 có thể đọc là 夜奢 gặp 馬鳴 rồi trao pháp, hoặc 夜奢 nhận pháp từ 馬鳴. Câu không tự phân xử. | Không đủ căn cứ chọn chiều. | QA-04: xét riêng. |
| RC-6d067420c17c | 12 馬鳴大士 → 13 迦毗摩羅 | subject_to_object (ứng viên, chưa chấp nhận đại từ) | 攝伏迦毗摩羅為弟子，遂以法付之 | 0321a82 | 之 là đại từ làm đối tượng của 付. Trong cùng câu, 迦毗摩羅 là đối tượng của 攝伏…為弟子. Đề xuất 之 = 迦毗摩羅. | Hợp lý theo cấu trúc câu, chưa chắc chắn. Đây là đề xuất, chưa accepted identity. | QA-05: chấp nhận hay bác bước giải đại từ. |
| RC-cd3fe29462b1 | 14 龍樹尊者 → 15 迦那提婆 | subject_to_object | 將垂滅度，乃以其法印付迦那提婆 | 0322a10 | Long Thọ trao pháp ấn cho 迦那提婆. Tên đầy đủ. | Đủ căn cứ câu chữ. | Không |
| RC-cb02aebecc9a | 24 師子尊者 → 25 婆舍斯多 | subject_to_object | 以法授婆舍斯多 | 0322a69 | 師子尊者 trao pháp cho 婆舍斯多. Dùng động từ 授. | Đủ căn cứ câu chữ. | Không |
| RC-54484d3c8d5b | 25 婆舍斯多 → 26 不如密多 | subject_to_object | 從婆舍斯多出家付法 | 0323a09 | 不如密多 xuất gia từ 婆舍斯多 và được trao pháp. Đọc được theo mẫu 從X出家付法. | Hợp lý. Mục 26 tên 不如密多, mục 27 viết 不如蜜多 (dị bản chữ), không ảnh hưởng cặp này. | Không bắt buộc. |
| RC-a151d1f6e0e2 | 26 不如密多 → 27 般若多羅 | subject_to_object | 以正法眼藏付般若多羅 | 0323a11 | 不如密多 trao 正法眼藏 cho 般若多羅. | Đủ căn cứ câu chữ. Mục 27 có 遇不如蜜多 (dị bản), chưa liên kết. | QA: quyết định dị bản 密/蜜 cho mục 26–27. |
| RC-639d023a3086 | 27 般若多羅 → 28 菩提達磨 | **unknown** (ứng viên) | 得菩提達磨付法 (mục 27, 0323a17); 從般若多羅出家付法 (mục 28, 0323a21) | 0323a17, 0323a21 | Hai câu cùng chiều, nhưng 得X付法 đọc được hai cách. Câu mục 28 là chứng cứ mạnh hơn. | Chiều chưa chắc chắn từ câu 得X付法. Câu 從X出家付法 hỗ trợ 27→28. | QA-02: xác nhận. |
| RC-2eae0012e122 | 29 慧可 → 30 僧璨 | subject_to_object | 後傳法僧璨 | 0323a40 | 慧可 truyền pháp cho 僧璨. Mục 30 còn có 受度傳法 (thọ độ và truyền pháp). Phần 受度 là thọ giới, không gán vào claim này. | Đủ căn cứ câu chữ cho truyền pháp. Phần thọ độ cần tách riêng nếu muốn ghi. | Ghi chú: phân biệt thọ độ và truyền pháp khi QA. |
| RC-c1ae9cef4a86 | 30 僧璨 → 31 道信 | subject_to_object (cách đọc theo câu) | 後得道信，付以法眼 | 0323a51 | Câu nêu 僧璨 trao 法眼 sau khi 得 道信. Cách đọc này rõ hơn 得X付法 của mục 27. | Hợp lý theo câu. Vẫn chỉ là cách đọc, chưa xác nhận. | QA-03: xác nhận cách đọc. |

## Chưa phải claim, cần để ý

| Cặp hoặc mục | Lý do chưa có claim | Ghi chú kiểm tay |
|---|---|---|
| 4 → 5 (優波毱多 → 提多迦) | 「遇優波尊者，為釋夢義，得受正法」 (mục 5). Tên 優波尊者 không khớp đầy đủ với 優波毱多. | Gần như chắc chắn là mục 4, nhưng luật không liên kết tên rút gọn. Cần QA quyết định có thêm bảng tên rút gọn hay không. |
| 9 → 10 (伏駄密多 → 脇尊者) | Không có câu truyền pháp rõ ràng. | Không có claim. |
| 12 → 13 đã có ứng viên | Xem RC-6d067420c17c. | |
| 13 → 14 (迦毗摩羅 → 龍樹) | 「因得龍樹為弟子，付正法藏」. Tên 龍樹 là rút gọn của 龍樹尊者. | Gợi ý đúng chiều, không liên kết. Cần tên rút gọn. |
| 16 → 17 (羅睺羅多 → 僧伽難提) | 「因羅睺羅多至，傳大法要」 (mục 17). Vai trò không xác định. | Unresolved. Cần đọc ngữ cảnh đầy đủ. |
| 17 → 18, 31 → 32 | Mục 18 và 32 không có câu truyền pháp nêu người nhận. Mục 31 không có động từ truyền pháp. | Không có cạnh. |
| 19 → 20 (鳩摩羅多 → 闍夜多) | 「遇闍夜尊者，付以法眼」. Tên 闍夜尊者 là rút gọn của 闍夜多. | Gần như chắc chắn, nhưng luật không liên kết tên rút gọn. |
| 21 → 22 | 「父命師婆修槃頭，出家付法」. Người trao không nêu rõ. | Unresolved. |

## Tổng hợp kiểm tay

- Đủ căn cứ câu chữ (không cần QA thêm về chiều): 0→1, 2→3, 3→4, 8→9, 14→15, 24→25, 26→27, 29→30. Tám claim. Vẫn `pending`.
- Hợp lý, cần xác nhận một quy ước: 5→6, 6→7, 25→26, 30→31.
- Chiều chưa chắc (QA quyết định): 8→7 (QA-01), 27→28 (QA-02), 11→12 (QA-04).
- Đại từ đề xuất (QA-05): 12→13.
- Cần QA xem dị bản và tên rút gọn trước khi mở rộng: 不如密多/不如蜜多 (26–27), 優波尊者 (4–5), 龍樹 (13–14), 闍夜尊者 (19–20), 難提尊者 (8–9), 夜奢 (10–11).

Không kiểm được ảnh trang bản in trong phiên này. Mọi việc đối chiếu ảnh vẫn là việc của QA.
