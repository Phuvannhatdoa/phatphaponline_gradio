# Quyền và điều kiện sử dụng (v0.2)

## Nguồn
Trích nguyên văn từ `teiHeader/fileDesc/publicationStmt/availability` của X86n1601:

> Available for non-commercial use when distributed with this header intact.

Điều kiện theo nguồn: sử dụng phi thương mại, và phải giữ nguyên header khi phân phối.

## Trạng thái
- `source/X86n1601.source.xml`: giữ nguyên điều kiện trên. Người phát hành phải giữ header nguyên vẹn.
- `derived/X86n1601.pilot.claims.xml`: dữ liệu dẫn xuất. Quyền chưa được xác định. Trạng thái `pending-review`.
- `scripts/`, `schema/`, `tests/`: không gắn giấy phép. Trạng thái `pending-review`.
- `reports/`, `README-VI.md`: trạng thái `pending-review`.

## Lưu ý
- Gói v0.1 kết luận CC BY-NC-SA 4.0 cho toàn bộ. Gói không lưu chứng cứ đủ để giữ kết luận đó. Header không ghi tên CC và cũng không tự chứng minh chính sách CC bên ngoài không áp dụng. v0.2 không dùng kết luận này và giữ `pending-review`.
- Không áp văn bản CC license máy móc lên scripts hoặc XSD.
- Quyết định quyền cuối cùng thuộc về người có thẩm quyền, không thuộc về cloud session.
