# Changelog v0.1 → v0.2 → v0.2.1

## v0.2.1 (theo quyết định QA trên v0.2)
- Áp dụng quyết định trong `manual/qa-decisions-v0.2.1.json` qua `--decisions`. Mỗi quyết định có mã (QA-01 … QA-05) và được ghi vào claim bằng `decisionRef`.
- Claim 8→7: chiều `unknown`, giữ ứng viên `candidateDirection=subject_to_object`. Không đảo sang 7→8.
- Claim 27→28 và 11→12: chiều `unknown`, có ứng viên. Xét từng câu, không dùng luật chung cho 得X付法.
- Claim 30→31: giữ `subject_to_object` như cách đọc theo câu. Vẫn `pending`.
- Thêm claim ứng viên 12→13 (之 → 迦毗摩羅) với `pronounResolution` (đại từ, antecedentRef, method, status=proposed). Không accepted identity.
- Đổi `quote` thành `normalizedQuote`, kèm `normalizationRule` ghi rõ quy tắc chuẩn hóa. `rawSnippet` giữ nguyên bản.
- Schema lên 2.1: thêm `candidateDirection`, `decisionRef`, `pronounResolution`, `reviewNote`, `normalizationRule`.
- Validator: kiểm antecedent của đại từ bằng đối tượng của claim; kiểm `normalizedQuote` thay cho `quote`.
- Test: 30 test (thêm 6 test quyết định QA).
- Thêm `reports/manual-review-16-claims.md`: kiểm tay từng claim.

## Nguồn
- Khóa nguồn bằng SHA-256, kích thước 796,393 byte, commit, blob và URL upstream. v0.1 ghi 778 KB, sai.
- Tách `retrievedAt` (xấp xỉ, từ log phiên), `cbetaHeaderDate` (ngày trong header) và thời gian chạy (chỉ trong run-manifest).
- Quyền: v0.1 kết luận CC BY-NC-SA 4.0, nhưng gói không có chứng cứ đủ để giữ kết luận đó. v0.2 không dùng kết luận này. Điều kiện trích nguyên văn từ header CBETA, trạng thái `pending-review`.

## Kỹ thuật (v0.2)
- Đường dẫn hardcode được thay bằng CLI `--source --output --schema`.
- Tách lớp: person, mention, evidence, relationClaim, generationLabel, unresolvedCase. ID theo hash nguồn và locator. Không dùng DILA.
- Evidence giữ xml:id mục, XPath, trang ed=X, dòng ed=X đầu và cuối, `rawStart`/`rawEnd`, `rawSnippet` (có xuống dòng) và chuỗi chuẩn hóa.
- Bỏ giới hạn bảy tên và `break`. Một mục có thể cho nhiều cạnh.
- Thêm luật R1–R4. Không dùng thứ tự kế tiếp hay tên giống nhau.
- Phủ định không tạo cạnh. Chiều đảo được gắn cờ, không tự đổi.
- Mỗi claim bắt buộc có ít nhất một `evidenceRef` (XSD `minOccurs="1"`).
- Validator chạy XSD thật (xmllint), so hash bytes nguồn, kiểm locator và chuỗi, kiểm ID và ref.
- Sửa trong quá trình phát triển: ký tự xuống dòng làm vỡ tên và động từ khi khớp; trang và dòng không được gán cho các mục đầu, và đọc `pb` nằm giữa các mục.
- v0.1 không có locator trang hay dòng. v0.2 thêm chúng.

## Kết quả
- v0.1: 9 claim. v0.2: 15 claim. v0.2.1: 16 claim (có thêm ứng viên đại từ 12→13).
- Chi tiết đối soát: `reports/claim-reconciliation-v0.1-to-v0.2.md`.

## Không làm trong v0.2.1
- Không import DB, không API, không export.
- Không gán DILA, không tính số đời PTDA.
- Không mở rộng sang quyển 002–009.
- Không đối chiếu ảnh trang bản in.
