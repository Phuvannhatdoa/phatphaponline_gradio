#!/usr/bin/env python3
"""PTDA lineage pilot extractor, v0.2.

Scope: CBETA X86n1601 section headed 三十三祖世系圖 (the 34-entry list in juan 001).
Output: a candidate PTDA claims XML. Every relation claim cites evidence; anything
that cannot be settled from the sentence is written to unresolvedCases instead.

Usage (run with -I so no local module can shadow the stdlib):
    python3 -I scripts/extract_lineage.py --source SRC.xml --output OUT.xml \
        --schema schema/ptda-lineage-v1.xsd [--run-manifest RUN.json]

No network access, no DB, no external entities (ElementTree does not expand them).
"""
import argparse
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from xml.sax.saxutils import escape, quoteattr

TEI = "{http://www.tei-c.org/ns/1.0}"
CB = "{http://www.cbeta.org/ns/1.0}"
XML_ID = "{http://www.w3.org/XML/1998/namespace}id"
PTDA_NS = "urn:ptda:research:lineage:1"
SCHEMA_VERSION = "2.0"
EXTRACTOR_VERSION = "0.2.0"
RULE_ID = "PTDA-X86-LIN"
SECTION_MARK = "三十三祖"
CLAUSE_BREAK = "，。；：、！？"
PUNCT = set(CLAUSE_BREAK)

# Verb forms that carry dharma transmission in this section.
TRANSMIT_VERBS = ["付囑", "付以", "付", "授", "傳法", "傳大法要", "受正法", "受大法印", "囑"]
# Honorific affixes are never evidence of a short name.
HONORIFIC_AFFIXES = {"尊者", "大士", "大師", "和尚", "長者", "禪師", "論師", "菩薩"}
# Receipt / encounter markers that introduce the other party of a transmission.
RECEIPT_MARKERS = ("遇", "得", "從", "因")


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def stable_id(prefix, *parts):
    """Deterministic source-local ID. Not a DILA ID."""
    digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()
    return f"{prefix}-{digest[:12]}"


# ---------------------------------------------------------------- parsing

def find_section(root):
    body = root.find(f"{TEI}text/{TEI}body")
    for div in body.iter(f"{CB}div"):
        mulu = div.find(f"{CB}mulu")
        if mulu is not None and SECTION_MARK in (mulu.text or ""):
            return div
    raise ValueError(f"section containing {SECTION_MARK!r} not found")


def item_name_and_labels(item):
    """Top-level <note> is the generation label; the text after the first note up to
    a line break is the person name; later <note> elements are inline alternatives."""
    notes = item.findall(f"{TEI}note")
    label = (notes[0].text or "").strip() if notes else ""
    tail = notes[0].tail if notes else ""
    name = re.split(r"[\n\r]", tail or "")[0].strip()
    aliases = [(n.text or "").strip() for n in notes[1:] if (n.text or "").strip()]
    return name, label, aliases


class Token:
    """One source character. `orig` indexes the item's raw text so the exact source
    snippet (with CBETA line breaks) can be recovered."""
    __slots__ = ("ch", "x_line", "page", "p_id", "orig")

    def __init__(self, ch, x_line, page, p_id, orig):
        self.ch, self.x_line, self.page, self.p_id, self.orig = ch, x_line, page, p_id, orig


def item_tokens(item, state):
    """Flatten an item's body text (notes excluded) keeping CBETA ed=X locators.
    Whitespace is layout only: it is dropped from matching text but kept in `raw`."""
    out = []

    def walk(elem, p_id):
        if elem.tag == f"{TEI}note":
            return  # labels/alternatives are handled separately
        if elem.tag == f"{TEI}lb" and elem.get("ed") == "X":
            state["line"] = elem.get("n")
        elif elem.tag == f"{TEI}pb" and elem.get("ed") == "X":
            state["page"] = elem.get("n")
        this_p = elem.get(XML_ID) if elem.tag == f"{TEI}p" else p_id
        for ch in elem.text or "":
            out.append((ch, state["line"], state["page"], this_p))
        for child in elem:
            walk(child, this_p)
            for ch in child.tail or "":
                out.append((ch, state["line"], state["page"], this_p))

    walk(item, None)
    raw = "".join(c for c, *_ in out)
    toks = [Token(c, ln, pg, pp, i) for i, (c, ln, pg, pp) in enumerate(out) if not c.isspace()]
    return toks, raw


def clauses(tokens):
    """Split tokens into clauses at punctuation. Returns list of (start, end) indexes
    into tokens, end exclusive, punctuation excluded."""
    spans, start = [], 0
    for i, t in enumerate(tokens + [Token("。", None, None, None, None)]):
        if t.ch in PUNCT:
            if i > start:
                spans.append((start, i))
            start = i + 1
    return spans


# ---------------------------------------------------------------- rules

def load_items(root):
    section = find_section(root)
    lst = section.find(f"{TEI}list")
    items = []
    # Seed the CBETA page/line from the last ed=X markers before the section starts,
    # so entries that open before the first in-section pb still carry a locator.
    inside = {id(e) for e in section.iter()}
    state = {"line": None, "page": None}
    for el in root.iter():
        if id(el) in inside:
            break
        if el.tag == f"{TEI}pb" and el.get("ed") == "X":
            state["page"] = el.get("n")
        elif el.tag == f"{TEI}lb" and el.get("ed") == "X":
            state["line"] = el.get("n")
    idx = 0
    # Walk the list in document order so page/line milestones between entries (pb, lb
    # that sit outside <item>) update the locator state before the next entry is read.
    for child in lst:
        if child.tag == f"{TEI}pb" and child.get("ed") == "X":
            state["page"] = child.get("n")
            continue
        if child.tag == f"{TEI}lb" and child.get("ed") == "X":
            state["line"] = child.get("n")
            continue
        if child.tag != f"{TEI}item":
            continue
        it = child
        name, label, aliases = item_name_and_labels(it)
        toks, raw = item_tokens(it, state)
        items.append({
            "index": idx,
            "xml_id": it.get(XML_ID),
            "name": name,
            "label": label,
            "aliases": aliases,
            "tokens": toks,
            "raw": raw,
        })
        idx += 1
    return items


def name_index(items):
    """Map each name (and each inline note alias) to an item index.
    Only names with a unique match are used; duplicates go to ambiguous."""
    seen = {}
    for it in items:
        for nm in [it["name"]] + it["aliases"]:
            if nm:
                seen.setdefault(nm, set()).add(it["index"])
    return {nm: next(iter(ix)) for nm, ix in seen.items() if len(ix) == 1}


def find_names(text, names):
    """Return (pos, name, index) for every occurrence, longest name first, no overlaps."""
    hits, taken = [], set()
    for nm in sorted(names, key=len, reverse=True):
        for m in re.finditer(re.escape(nm), text):
            span = set(range(m.start(), m.end()))
            if span & taken:
                continue
            taken |= span
            hits.append((m.start(), nm, names[nm]))
    return sorted(hits)


def verb_hits(text):
    hits, taken = [], set()
    for v in TRANSMIT_VERBS:
        for m in re.finditer(re.escape(v), text):
            span = set(range(m.start(), m.end()))
            if span & taken:
                continue
            taken |= span
            hits.append((m.start(), v))
    return sorted(hits)


def negated(text, pos):
    return bool(re.search(r"[不未無非]$", text[max(0, pos - 2):pos]))


def extract(items, src_sha):
    names = name_index(items)
    claims, unresolved = {}, []
    for it in items:
        toks = it["tokens"]
        text = "".join(t.ch for t in toks)
        spans = clauses(toks)
        clause_texts = [text[s:e] for s, e in spans]
        # Clause texts with the item's own name removed from the header clause.
        for ci, (s, e) in enumerate(spans):
            ctext = clause_texts[ci]
            names_here = [h for h in find_names(ctext, names) if h[2] != it["index"]]
            verbs = verb_hits(ctext)
            if not verbs:
                continue
            for vpos, verb in verbs:
                before = [h for h in names_here if h[0] < vpos]
                after = [h for h in names_here if h[0] > vpos]
                ev_span = (s, e)
                if negated(ctext, vpos):
                    unresolved.append(make_case(it, ev_span, "negated_transmission", None,
                                                f"verb {verb} is negated in clause; no edge asserted"))
                    continue
                # R1: current item gives to a named person after the verb.
                if verb in ("付", "付囑", "付以", "授", "傳法", "囑") and after and verb != "囑":
                    _, nm, j = after[0]
                    add_claim(claims, it["index"], j, "subject_to_object", verb, "R1", ctext, ev_span, it, toks)
                    continue
                # R2: "從X出家付法" — the named person X gives to the current item.
                if verb in ("付", "付以", "傳法", "授") and before and ctext[max(0, before[-1][0] - 1)] == "從" \
                        and not after:
                    _, nm, j = before[-1]
                    add_claim(claims, j, it["index"], "subject_to_object", verb, "R2", ctext, ev_span, it, toks)
                    continue
                # R3: "遇X / 得X" earlier in the item, then this clause gives dharma with no
                # explicit receiver: the current item gives to X.
                if verb in ("付", "付以", "授") and not after:
                    prev = clause_texts[ci - 1] if ci > 0 else ""
                    marked = [h for h in find_names(prev, names) if h[0] < len(prev)
                              and prev[max(0, h[0] - 1)] in RECEIPT_MARKERS]
                    if len(marked) == 1 and marked[0][2] != it["index"]:
                        j = marked[0][2]
                        ev = (spans[ci - 1][0], e)
                        add_claim(claims, it["index"], j, "subject_to_object", verb, "R3", text[ev[0]:ev[1]], ev, it, toks)
                        continue
                    same = [h for h in find_names(ctext, names) if h[0] < vpos and ctext[max(0, h[0] - 1)] in RECEIPT_MARKERS
                            and h[2] != it["index"]]
                    if len(same) == 1:
                        j = same[0][2]
                        add_claim(claims, it["index"], j, "subject_to_object", verb, "R3", ctext, ev_span, it, toks)
                        continue
                # R4: a named person before the verb gives to the current item (implicit receiver).
                if before and not after and verb in ("付", "付以", "授") and ctext[max(0, before[-1][0] - 1)] not in RECEIPT_MARKERS + ("從",):
                    _, nm, j = before[-1]
                    add_claim(claims, j, it["index"], "subject_to_object", verb, "R4", ctext, ev_span, it, toks,
                              flags=["text_direction_differs_from_list_order"] if j > it["index"] else [])
                    continue
                # Otherwise: verb present but roles are not settled by the rules.
                if verb == "囑" and after:
                    kind = "object_not_in_source_list"
                    reason = "entrustment verb; the named object is not a listed patriarch"
                elif not before and not after:
                    kind = "pronoun_or_context"
                    reason = "transmission verb with no named giver or receiver in the clause"
                else:
                    kind = "role_unclear"
                    reason = "named person present but giver or receiver cannot be fixed by the rules"
                unresolved.append(make_case(it, ev_span, kind, None, reason))
    unresolved += short_name_cases(items, names)
    return claims, unresolved, names


def short_name_cases(items, names):
    """Short forms (>=2-char prefix or suffix of a listed name) that occur in an item
    where the full name does not. They are never linked automatically."""
    cases = []
    # An affix shared by two or more listed names (e.g. 尊者, 大士) is generic and is skipped.
    affix_owners = {}
    for nm in names:
        for k in range(2, len(nm)):
            for aff in (nm[:k], nm[-k:]):
                affix_owners.setdefault(aff, set()).add(nm)
    for it in items:
        text = "".join(t.ch for t in it["tokens"])
        for nm in names:
            if len(nm) < 3 or nm in text:
                continue
            for k in range(len(nm) - 1, 1, -1):
                for pre in (nm[:k], nm[-k:]):
                    if len(affix_owners.get(pre, ())) != 1 or pre in HONORIFIC_AFFIXES:
                        continue
                    if pre in text and pre != it["name"]:
                        pos = text.index(pre)
                        span = (max(0, pos - 2), min(len(text), pos + len(pre) + 2))
                        cases.append(make_case(
                            it, span, "short_or_variant_name", None,
                            f"'{pre}' occurs where the full name '{nm}' does not; short forms are not linked automatically"))
                        break
                else:
                    continue
                break
    seen, out = set(), []
    for c in cases:
        k = (c["item_xml_id"], c["reason"])
        if k not in seen:
            seen.add(k)
            out.append(c)
    return out


def add_claim(claims, subj, obj, direction, verb, rule, ctext, span, item, toks, flags=None):
    key = (subj, obj)
    evid = make_evidence(item, span, toks)
    rec = claims.setdefault(key, {"subj": subj, "obj": obj, "direction": direction,
                                  "terms": [], "rules": [], "evidence": [], "flags": set()})
    if verb not in rec["terms"]:
        rec["terms"].append(verb)
    if rule not in rec["rules"]:
        rec["rules"].append(rule)
    if evid["id"] not in [e["id"] for e in rec["evidence"]]:
        rec["evidence"].append(evid)
    for f in flags or []:
        rec["flags"].add(f)


def make_evidence(item, span, toks):
    s, e = span
    seg = toks[s:e]
    raw = item["raw"]
    ev_id = stable_id("EV", item["xml_id"], str(s), str(e))
    return {
        "id": ev_id,
        "item_xml_id": item["xml_id"],
        "p_xml_id": seg[0].p_id,
        "page": seg[0].page,
        "line_start": seg[0].x_line,
        "line_end": seg[-1].x_line,
        "span_start": s,
        "span_end": e,
        "layer": "body",
        # quote: matching form, layout whitespace removed. raw_snippet: exact source text
        # including CBETA line breaks, recoverable from raw_start..raw_end of the item.
        "quote": "".join(t.ch for t in seg),
        "raw_snippet": raw[seg[0].orig:seg[-1].orig + 1],
        "raw_start": seg[0].orig,
        "raw_end": seg[-1].orig + 1,
        "context_before": "".join(t.ch for t in toks[max(0, s - 12):s]),
        "context_after": "".join(t.ch for t in toks[e:e + 12]),
    }


def make_case(item, span, kind, related, reason):
    return {
        "id": stable_id("UC", item["xml_id"], kind, str(span[0]), reason),
        "kind": kind,
        "item_xml_id": item["xml_id"],
        "span": span,
        "reason": reason,
        "related": related,
    }


# ---------------------------------------------------------------- output

def build_xml(src_info, items, claims, unresolved, names, out_path):
    lines = []
    w = lines.append
    w('<?xml version="1.0" encoding="UTF-8"?>')
    w(f'<lineageDataset xmlns="{PTDA_NS}" schemaVersion="{SCHEMA_VERSION}" '
      f'workId="X86n1601" status="candidate">')

    w("  <sourceManifest>")
    for k in ["fileName", "sha256", "byteSize", "sourceUrl", "sourceRepo", "sourceBranch",
              "sourceCommit", "sourceBlob", "cbetaHeaderVersion", "rightsStatus"]:
        w(f"    <{k}>{escape(str(src_info[k]))}</{k}>")
    w("  </sourceManifest>")

    w("  <processingScope>")
    w(f"    <juan>001</juan>")
    w(f"    <sectionMark>{escape(SECTION_MARK)}</sectionMark>")
    w(f"    <itemCount>{len(items)}</itemCount>")
    w(f"    <firstItemXmlId>{items[0]['xml_id']}</firstItemXmlId>")
    w(f"    <lastItemXmlId>{items[-1]['xml_id']}</lastItemXmlId>")
    w("    <notProcessed>juan 002-009; remaining sections of juan 001</notProcessed>")
    w("  </processingScope>")

    pid = {it["index"]: stable_id("SP", src_info["sha256"], it["xml_id"]) for it in items}
    w("  <persons>")
    for it in items:
        w(f'    <person id="{pid[it["index"]]}">')
        w(f"      <sourceItemXmlId>{it['xml_id']}</sourceItemXmlId>")
        w(f"      <sourceLabel>{escape(it['label'])}</sourceLabel>")
        w(f"      <nameZh>{escape(it['name'])}</nameZh>")
        for a in it["aliases"]:
            w(f"      <alias>{escape(a)}</alias>")
        w("    </person>")
    w("  </persons>")

    # Mentions: every occurrence of a listed name in the body, one per evidence token span.
    w("  <mentions>")
    mention_no = 0
    for it in items:
        text = "".join(t.ch for t in it["tokens"])
        for pos, nm, j in find_names(text, names):
            mention_no += 1
            mid = stable_id("MN", src_info["sha256"], it["xml_id"], str(pos), nm)
            w(f'    <mention id="{mid}">')
            w(f"      <personRef ref=\"{pid[j]}\"/>")
            w(f"      <inItemXmlId>{it['xml_id']}</inItemXmlId>")
            w(f"      <surface>{escape(nm)}</surface>")
            w(f"      <offset>{pos}</offset>")
            w("    </mention>")
    w("  </mentions>")

    # Evidence: one entry per distinct clause cited by any claim or unresolved case.
    ev_map = {}
    for rec in claims.values():
        for ev in rec["evidence"]:
            ev_map[ev["id"]] = ev
    w("  <evidence>")
    for ev in sorted(ev_map.values(), key=lambda e: e["id"]):
        w(f'    <evidenceUnit id="{ev["id"]}">')
        w(f"      <itemXmlId>{ev['item_xml_id']}</itemXmlId>")
        w(f"      <xmlPath>//*[@xml:id='{ev['item_xml_id']}']" +
          (f"//*[@xml:id='{ev['p_xml_id']}']" if ev["p_xml_id"] else "") + "</xmlPath>")
        w(f"      <editionPage>{ev['page']}</editionPage>")
        w(f"      <lineStart edition=\"X\">{ev['line_start']}</lineStart>")
        w(f"      <lineEnd edition=\"X\">{ev['line_end']}</lineEnd>")
        w(f"      <layer>{ev['layer']}</layer>")
        w(f"      <spanStart>{ev['span_start']}</spanStart>")
        w(f"      <spanEnd>{ev['span_end']}</spanEnd>")
        w(f"      <quote>{escape(ev['quote'])}</quote>")
        w(f"      <rawStart>{ev['raw_start']}</rawStart>")
        w(f"      <rawEnd>{ev['raw_end']}</rawEnd>")
        w(f"      <rawSnippet>{escape(ev['raw_snippet'])}</rawSnippet>")
        w(f"      <contextBefore>{escape(ev['context_before'])}</contextBefore>")
        w(f"      <contextAfter>{escape(ev['context_after'])}</contextAfter>")
        w("    </evidenceUnit>")
    w("  </evidence>")

    w("  <relationClaims>")
    for key in sorted(claims, key=lambda k: (k[0], k[1])):
        rec = claims[key]
        cid = stable_id("RC", src_info["sha256"], pid[rec["subj"]], pid[rec["obj"]], rec["direction"])
        w(f'    <relationClaim id="{cid}">')
        w(f"      <subjectPersonRef ref=\"{pid[rec['subj']]}\"/>")
        w(f"      <objectPersonRef ref=\"{pid[rec['obj']]}\"/>")
        for t in rec["terms"]:
            w(f"      <sourceRelationTerm>{escape(t)}</sourceRelationTerm>")
        w("      <proposedRelationType>dharma_transmission</proposedRelationType>")
        w(f"      <directionStatus>{rec['direction']}</directionStatus>")
        for ev in rec["evidence"]:
            w(f"      <evidenceRef ref=\"{ev['id']}\"/>")
        w(f"      <extractionRule>{RULE_ID}-{'+'.join(sorted(rec['rules']))}</extractionRule>")
        w(f"      <extractionRuleVersion>{EXTRACTOR_VERSION}</extractionRuleVersion>")
        for f in sorted(rec["flags"]):
            w(f"      <flag>{f}</flag>")
        w("      <reviewStatus>pending</reviewStatus>")
        w("    </relationClaim>")
    w("  </relationClaims>")

    w("  <generationLabels>")
    for it in items:
        w(f"    <label itemXmlId=\"{it['xml_id']}\">{escape(it['label'])}</label>")
    w("  </generationLabels>")

    w("  <unresolvedCases>")
    for c in sorted(unresolved, key=lambda c: c["id"]):
        w(f'    <case id="{c["id"]}">')
        w(f"      <kind>{c['kind']}</kind>")
        w(f"      <itemXmlId>{c['item_xml_id']}</itemXmlId>")
        w(f"      <reason>{escape(c['reason'])}</reason>")
        w("    </case>")
    w("  </unresolvedCases>")
    w("</lineageDataset>")
    with open(out_path, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines) + "\n")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", required=True, help="path to X86n1601.xml (byte-exact CBETA)")
    ap.add_argument("--output", required=True, help="path for the candidate claims XML")
    ap.add_argument("--schema", required=True, help="path to ptda-lineage-v1.xsd (used by validate step)")
    ap.add_argument("--run-manifest", help="optional path for the run manifest (timestamps live here only)")
    ap.add_argument("--source-url", default="", help="URL the source was fetched from")
    ap.add_argument("--source-repo", default="", help="repository the source was fetched from")
    ap.add_argument("--source-branch", default="", help="branch or tag")
    ap.add_argument("--source-commit", default="", help="git commit that holds the source file")
    ap.add_argument("--source-blob", default="", help="git blob id of the source file")
    ap.add_argument("--header-version", default="", help="CBETA header version text if known")
    args = ap.parse_args(argv)

    with open(args.source, "rb") as f:
        raw = f.read()
    sha = sha256_bytes(raw)
    root = ET.fromstring(raw)
    items = load_items(root)
    claims, unresolved, names = extract(items, sha)

    src_info = {
        "fileName": args.source.replace("\\", "/").split("/")[-1],
        "sha256": sha,
        "byteSize": len(raw),
        "sourceUrl": args.source_url or "not recorded",
        "sourceRepo": args.source_repo or "not recorded",
        "sourceBranch": args.source_branch or "not recorded",
        "sourceCommit": args.source_commit or "not recorded",
        "sourceBlob": args.source_blob or "not recorded",
        "cbetaHeaderVersion": args.header_version or "not recorded",
        "rightsStatus": "pending-review",
    }
    build_xml(src_info, items, claims, unresolved, names, args.output)

    if args.run_manifest:
        manifest = {
            "extractorVersion": EXTRACTOR_VERSION,
            "ruleId": RULE_ID,
            "sourceSha256": sha,
            "persons": len(items),
            "relationClaims": len(claims),
            "evidenceUnits": len({e["id"] for r in claims.values() for e in r["evidence"]}),
            "unresolvedCases": len(unresolved),
            "runStartedAt": datetime.now(timezone.utc).isoformat(),
            "pythonVersion": sys.version.split()[0],
        }
        with open(args.run_manifest, "w", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
            f.write("\n")
    print(f"persons={len(items)} claims={len(claims)} unresolved={len(unresolved)} output={args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
