# Changelog v0.1 → v0.2

## Nguồn
- Khóa nguồn bằng SHA-256, kích thước 796,393 byte, commit, blob và URL upstream. v0.1 ghi 778 KB, sai.
- Tách `retrievedAt` (xấp xỉ, từ log phiên), `cbetaHeaderDate` (ngày trong header) và thời gian chạy (chỉ trong run-manifest).
- Quyền: v0.1 ghi CC BY-NC-SA 4.0. Đây là sai. Header CBETA ghi điều kiện "non-commercial ... with this header intact". v0.2 trích nguyên văn và giữ `pending-review`.

## Kỹ thuật
- Đường dẫn hardcode được thay bằng CLI `--source --output --schema`.
- Tách lớp: person, mention, evidence, relationClaim, generationLabel, unresolvedCase. ID theo hash nguồn và locator. Không dùng DILA.
- Evidence giữ xml:id mục, XPath, trang ed=X, dòng ed=X đầu và cuối, `rawStart`/`rawEnd`, `rawSnippet` (có xuống dòng) và `quote` (không khoảng trắng).
- Bỏ giới hạn bảy tên và `break`. Một mục có thể cho nhiều cạnh.
- Thêm luật R1–R4. Không dùng thứ tự kế tiếp hay tên giống nhau.
- Phủ định không tạo cạnh. Chiều đảo được gắn cờ, không tự đổi.
- Mỗi claim bắt buộc có ít nhất một `evidenceRef` (XSD `minOccurs="1"`).
- Validator chạy XSD thật (xmllint), so hash bytes nguồn, kiểm locator và quote, kiểm ID và ref. Không coi container rỗng là đủ chứng cứ.
- Test: 24 test, gồm fixture có nhãn, test trên nguồn thật, và test đột biến validator. Test đột biến kỳ vọng FAIL.
- v0.1 không có locator trang hay dòng. v0.2 thêm `editionPage`, `lineStart`, `lineEnd` (ed=X), đọc `pb`/`lb` theo thứ tự tài liệu kể cả giữa các mục.
- Trong quá trình phát triển v0.2, phát hiện ký tự xuống dòng làm vỡ tên và động từ khi khớp. Đã sửa: khớp trên chuỗi không khoảng trắng, quote là dạng không khoảng trắng, rawSnippet giữ nguyên.

## Kết quả
- Claim: v0.1 9 → v0.2 15. Chi tiết trong `reports/claim-reconciliation-v0.1-to-v0.2.md`.
- v0.1 claim_0004 đảo chiều (sửa thành 8→7, có cờ).
- v0.1 claim_0005 chưa đủ bằng chứng (đại từ 之).
- Thêm 7 cặp mới.

## Không làm trong v0.2
- Không import DB, không API, không export.
- Không gán DILA, không tính số đời PTDA.
- Không mở rộng sang quyển 002–009.
