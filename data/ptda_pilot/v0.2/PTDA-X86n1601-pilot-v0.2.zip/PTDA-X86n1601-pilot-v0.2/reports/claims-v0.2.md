# Bảng claim v0.2 (sinh từ derived/X86n1601.pilot.claims.xml)

Trạng thái: pending. Chiều: `subject_to_object` nghĩa là chủ thể trao pháp cho đối tượng, theo luật R1–R4.

| Claim | Từ (chỉ số) | Đến (chỉ số) | Động từ (chữ Hán nguồn) | Chiều | Luật | Cờ | Số chứng cứ | Trang ed=X | Dòng ed=X | Chứng cứ chính (quote) |
|---|---|---|---|---|---|---|---|---|---|---|
| RC-5853eb223039 | 0 釋迦牟尼佛 | 1 摩訶迦葉 | 付囑 | subject_to_object | R1 | - | 1 | 0320a | 0320a22–22 | 乃以大法印付囑摩訶迦葉 |
| RC-96af990ee99f | 2 阿難尊者 | 3 商那和修 | 付 | subject_to_object | R1 | - | 1 | 0321a | 0321a15–16 | 乃以法付其弟子商那和修 |
| RC-16a7c736bed6 | 3 商那和修 | 4 優波毱多 | 付 | subject_to_object | R1 | - | 1 | 0321a | 0321a26–27 | 後以法付優波毱多 |
| RC-bae3b16dcbef | 5 提多迦 | 6 彌遮迦 | 付 | subject_to_object | R1 | - | 1 | 0321a | 0321a41–41 | 後付彌遮迦 |
| RC-1aafe0d1f7b1 | 6 彌遮迦 | 7 婆須蜜 | 付以 | subject_to_object | R3 | - | 1 | 0321a | 0321a47–47 | 遇婆須蜜，付以法 |
| RC-62d538e8d9ca | 8 佛陀難提 | 7 婆須蜜 | 付以 | subject_to_object | R4 | text_direction_differs_from_list_order | 1 | 0321a | 0321a52–53 | 佛陀難提付以正法 |
| RC-eec1bda360b3 | 8 佛陀難提 | 9 伏駄密多 | 付 | subject_to_object | R1 | - | 1 | 0321a | 0321a59–60 | 以法付伏駄密多 |
| RC-b6acfa34f8b1 | 11 富那夜奢 | 12 馬鳴大士 | 付 | subject_to_object | R3 | - | 1 | 0321a | 0321a75–76 | 得馬鳴大士付正法眼藏 |
| RC-cd3fe29462b1 | 14 龍樹尊者 | 15 迦那提婆 | 付 | subject_to_object | R1 | - | 1 | 0322a | 0322a10–11 | 乃以其法印付迦那提婆 |
| RC-cb02aebecc9a | 24 師子尊者 | 25 婆舍斯多 | 授 | subject_to_object | R1 | - | 1 | 0322a | 0322a69–69 | 以法授婆舍斯多 |
| RC-54484d3c8d5b | 25 婆舍斯多 | 26 不如密多 | 付 | subject_to_object | R2 | - | 1 | 0323a | 0323a09–10 | 從婆舍斯多出家付法 |
| RC-a151d1f6e0e2 | 26 不如密多 | 27 般若多羅 | 付 | subject_to_object | R1 | - | 1 | 0323a | 0323a11–12 | 以正法眼藏付般若多羅 |
| RC-9570dcc3f470 | 27 般若多羅 | 28 菩提達磨 | 付 | subject_to_object | R2+R3 | - | 2 | 0323a | 0323a17–18 | 得菩提達磨付法 |
| RC-2eae0012e122 | 29 慧可 | 30 僧璨 | 傳法 | subject_to_object | R1 | - | 1 | 0323a | 0323a40–41 | 後傳法僧璨 |
| RC-c1ae9cef4a86 | 30 僧璨 | 31 道信 | 付以 | subject_to_object | R3 | - | 1 | 0323a | 0323a51–52 | 後得道信，付以法眼 |

Ghi chú: dòng ed=X được rút gọn ở cột cuối. Đầy đủ locator (xml:id, XPath, rawStart/rawEnd, rawSnippet) nằm trong derived/X86n1601.pilot.claims.xml.
