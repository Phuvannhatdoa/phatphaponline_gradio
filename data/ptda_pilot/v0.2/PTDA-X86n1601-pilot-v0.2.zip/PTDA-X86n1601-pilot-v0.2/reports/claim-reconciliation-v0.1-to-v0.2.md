# Đối soát chín claim v0.1 với v0.2

Trạng thái mọi claim: `pending`. Không có claim nào được đánh dấu xác nhận lịch sử.
Dòng trích là dòng ed=X trong CBETA. Chỉ số mục là thứ tự trong danh sách 三十三祖世系圖 (0 = 釋迦牟尼佛, 33 = 慧能).

| v0.1 | Cặp v0.1 (chỉ số) | Kết quả v0.2 | Chứng cứ v0.2 (dòng ed=X) | Lý do |
|---|---|---|---|---|
| claim_0001 | 釋迦牟尼佛 → 摩訶迦葉 (0→1) | **Giữ** | 「乃以大法印付囑摩訶迦葉」 (0320a22), R1 | v0.1 trích cả đoạn tiểu sử để làm chứng cứ; v0.2 trích đúng câu. |
| claim_0002 | 提多迦 → 彌遮迦 (5→6) | **Giữ** | 「後付彌遮迦」 (0321a41), R1 | Câu chứa tên người nhận ngay sau động từ. |
| claim_0003 | 彌遮迦 → 婆須蜜 (6→7) | **Giữ** | 「遇婆須蜜，付以法」 (0321a47), R3 | Tên đứng ở mệnh đề trước, có dấu 遇; mệnh đề sau không nêu người nhận. |
| claim_0004 | 婆須蜜 → 佛陀難提 (7→8) | **Sửa chiều, gắn cờ** | Thành 8→7: 「佛陀難提付以正法」 (0321a52), R4 | Câu nêu 佛陀難提 là người trao pháp. v0.1 đảo chiều. Cờ `text_direction_differs_from_list_order` vì thứ tự danh sách đặt 7 trước 8. Không tạo cạnh 7→8. Cần QA xem đây là lỗi nguồn hay lỗi trình bày. |
| claim_0005 | 馬鳴大士 → 迦毗摩羅 (12→13) | **Chưa đủ bằng chứng (unresolved)** | 「攝伏迦毗摩羅為弟子，遂以法付之」 (mục 12): 之 là đại từ | Người nhận là đại từ 之. Quy tắc v0.2 không tự gán đại từ vào tên trước đó. Giữ ở `pronoun_or_context`. Có thể nhận thành claim sau khi QA quyết định chấp nhận quy ước đại từ. |
| claim_0006 | 龍樹尊者 → 迦那提婆 (14→15) | **Giữ** | 「乃以其法印付迦那提婆」 (0322a10), R1 | Tên đầy đủ, khớp đúng. |
| claim_0007 | 師子尊者 → 婆舍斯多 (24→25) | **Giữ** | 「以法授婆舍斯多」 (0322a69), R1 | Động từ 授 (trao). |
| claim_0008 | 般若多羅 → 菩提達磨 (27→28) | **Giữ, hai chứng cứ** | Mục 27: 「得菩提達磨付法」 (0323a17), R3. Mục 28: 「從般若多羅出家付法」 (0323a21), R2 | Hai câu cùng chiều. Lưu ý: 「得X付法」 là mẫu câu có thể hiểu nhiều cách. Chiều lấy theo ngữ pháp mục hiện tại trao cho X. Đề nghị QA đọc lại. |
| claim_0009 | 僧璨 → 道信 (30→31) | **Giữ** | 「後得道信，付以法眼」 (0323a51), R3 | Cùng mẫu 「得X，付」 ở claim_0008. |

## Claim v0.2 không có trong v0.1 (7 cặp)

| Cặp | Chứng cứ | Luật |
|---|---|---|
| 2→3 阿難尊者 → 商那和修 | 「乃以法付其弟子商那和修」 (0321a15) | R1 |
| 3→4 商那和修 → 優波毱多 | 「後以法付優波毱多」 (0321a26) | R1 |
| 8→9 佛陀難提 → 伏駄密多 | 「以法付伏駄密多」 (0321a59) | R1 |
| 11→12 富那夜奢 → 馬鳴大士 | 「得馬鳴大士付正法眼藏」 (0321a75) | R3 |
| 25→26 婆舍斯多 → 不如密多 | 「從婆舍斯多出家付法」 (0323a09) | R2 |
| 26→27 不如密多 → 般若多羅 | 「以正法眼藏付般若多羅」 (0323a11) | R1 |
| 29→30 慧可 → 僧璨 | 「後傳法僧璨」 (0323a40) | R1 |

## Tóm tắt

- v0.1: 9 claim. Giữ 7 cặp, 1 cặp đảo chiều (claim_0004), 1 cặp chưa đủ bằng chứng (claim_0005).
- v0.2: 15 claim. Gồm 7 cặp giữ lại, 1 cặp đảo chiều (8→7), 7 cặp mới.
- Không ép đủ 9 hay 33 cạnh. Các mục không có câu truyền pháp rõ ràng vẫn không có cạnh, và được ghi trong `unresolvedCases`.
