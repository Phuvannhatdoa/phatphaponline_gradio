# Khảo sát cấu trúc X86n1601 (v0.2)

Nguồn: `source/X86n1601.source.xml`, 796,393 byte, 7,564 dòng, SHA-256 `60a282bf…e84f178`.

## Đếm toàn file (đã đo)

| Thẻ | Số lượng |
|---|---|
| list | 1,147 |
| item | 5,876 |
| pb | 156 |
| lb | 13,282 |

Các số trên là số thẻ trong toàn file, không phải số người hay số quan hệ. Ví dụ 5,876 item gồm cả danh sách mục lục, chú thích và các mục không liên quan đến truyền pháp.

## Mục được xử lý

- Đoạn `cb:div` có `cb:mulu` chứa 三十三祖. Trong đó có một `tei:list` với 34 `tei:item` trực tiếp.
- Mỗi `item` có một `tei:note` đầu tiên là nhãn đời (始祖, 第一祖, 二祖, …, 三十三祖). Văn bản ngay sau note đó đến dấu xuống dòng là tên người.
- Note thứ hai (nếu có) là tên thay thế trong cùng mục. Chỉ có một trường hợp: 釋迦文佛 của mục 0.
- Thân mục nằm trong `tei:p`, có `lb ed="X"` và `lb ed="R147"`. Khoảng dòng dùng `ed="X"`.
- `pb ed="X"` nằm giữa các mục, không nằm trong `item`. Extractor v0.2 đọc chúng theo thứ tự tài liệu để gán trang.

## Những gì không được mã hóa thành cấu trúc

- Không có `cb:div` lồng hay bảng (`tei:table`) trong mục này.
- Không có sơ đồ phả hệ được mã hóa. Tiêu đề 三十三祖世系圖 chỉ là nhãn của danh sách văn bản.
- Quan hệ chỉ được diễn đạt trong câu văn. Không có thuộc tính XML nào biểu diễn cha–con.

Vì vậy quan hệ chỉ được lấy từ câu văn, theo luật trong `reports/extraction-rules.md`.

## Ngoài phạm vi

- Phần còn lại của quyển 001.
- Quyển 002–009. Không kiểm tra cấu trúc của các quyển này.
- Cấu trúc chi nhánh (ví dụ 曹溪大鑑下) không được khảo sát trong v0.2.

## Ghi chú về ký tự xuống dòng

CBETA ngắt dòng ngay trong tên và trong động từ (ví dụ 「商\n那和修」, 「付\n法」). Trong quá trình phát triển v0.2, luật khớp trên chuỗi thô đã bỏ sót các trường hợp này. v0.2 bỏ khoảng trắng khi khớp và giữ nguyên xuống dòng trong `rawSnippet`.
