# Trường hợp chưa giải quyết (v0.2)

Mỗi trường hợp là một câu hoặc mệnh đề có động từ truyền pháp (hoặc gợi ý tên rút gọn) mà luật không giải quyết được. Không trường hợp nào trong số này tạo cạnh.

## Tổng hợp

| Loại | Số |
|---|---|
| short_or_variant_name | 21 |
| pronoun_or_context | 19 |

## Danh sách

| Mã | Mục (chỉ số) | Loại | Lý do |
|---|---|---|---|
| UC-dc90d501867f | 0 釋迦牟尼佛 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-2b0a8459f0f6 | 1 摩訶迦葉 | short_or_variant_name | '阿難' occurs where the full name '阿難尊者' does not; short forms are not linked automatically |
| UC-3fe2170ed5f9 | 1 摩訶迦葉 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-c4aa712a692d | 1 摩訶迦葉 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-ca6bd1634aa6 | 1 摩訶迦葉 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-63f6d614432e | 2 阿難尊者 | short_or_variant_name | '多羅' occurs where the full name '般若多羅' does not; short forms are not linked automatically |
| UC-7922d0b08a92 | 2 阿難尊者 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-76e826c3b2e2 | 3 商那和修 | short_or_variant_name | '阿難' occurs where the full name '阿難尊者' does not; short forms are not linked automatically |
| UC-a33e745c16b1 | 3 商那和修 | short_or_variant_name | '舍多' occurs where the full name '伽耶舍多' does not; short forms are not linked automatically |
| UC-549c6bee225b | 4 優波毱多 | short_or_variant_name | '多迦' occurs where the full name '提多迦' does not; short forms are not linked automatically |
| UC-8d33c85ff4e5 | 5 提多迦 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-a551b954eaea | 5 提多迦 | short_or_variant_name | '優波' occurs where the full name '優波毱多' does not; short forms are not linked automatically |
| UC-671b987f7e79 | 7 婆須蜜 | short_or_variant_name | '摩羅' occurs where the full name '迦毗摩羅' does not; short forms are not linked automatically |
| UC-0c9fa2a0356b | 8 佛陀難提 | short_or_variant_name | '摩羅' occurs where the full name '迦毗摩羅' does not; short forms are not linked automatically |
| UC-985ac5d9e3a1 | 9 伏駄密多 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-12f131fa6e2d | 10 脇尊者 | short_or_variant_name | '夜奢' occurs where the full name '富那夜奢' does not; short forms are not linked automatically |
| UC-a4894bee2c6c | 10 脇尊者 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-daa6defea72b | 12 馬鳴大士 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-5f23b28510ac | 13 迦毗摩羅 | short_or_variant_name | '龍樹' occurs where the full name '龍樹尊者' does not; short forms are not linked automatically |
| UC-5f9c1e4f58cb | 13 迦毗摩羅 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-0c78dad8cdef | 15 迦那提婆 | short_or_variant_name | '龍樹' occurs where the full name '龍樹尊者' does not; short forms are not linked automatically |
| UC-5cec52266eac | 16 羅睺羅多 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-a3ea0916f3b4 | 16 羅睺羅多 | short_or_variant_name | '提婆' occurs where the full name '迦那提婆' does not; short forms are not linked automatically |
| UC-b40e14cc30a8 | 16 羅睺羅多 | short_or_variant_name | '多迦' occurs where the full name '提多迦' does not; short forms are not linked automatically |
| UC-ea3b28ed05b5 | 16 羅睺羅多 | short_or_variant_name | '迦毗' occurs where the full name '迦毗摩羅' does not; short forms are not linked automatically |
| UC-918e516f3d79 | 17 僧伽難提 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-5010bc122b07 | 19 鳩摩羅多 | short_or_variant_name | '摩羅' occurs where the full name '迦毗摩羅' does not; short forms are not linked automatically |
| UC-d39e722b90ba | 19 鳩摩羅多 | short_or_variant_name | '闍夜' occurs where the full name '闍夜多' does not; short forms are not linked automatically |
| UC-f6cee4161a0d | 19 鳩摩羅多 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-9805633ca612 | 20 闍夜多 | short_or_variant_name | '摩羅' occurs where the full name '迦毗摩羅' does not; short forms are not linked automatically |
| UC-1abc899617df | 21 婆修槃頭 | short_or_variant_name | '夜多' occurs where the full name '闍夜多' does not; short forms are not linked automatically |
| UC-34a1d5f36860 | 21 婆修槃頭 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-a93966628fd5 | 22 摩拏羅 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-e99bd034fb61 | 23 鶴勒那 | short_or_variant_name | '般若' occurs where the full name '般若多羅' does not; short forms are not linked automatically |
| UC-c5c20d2e91dd | 25 婆舍斯多 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-58c57f9df253 | 27 般若多羅 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-e4f013a65069 | 27 般若多羅 | short_or_variant_name | '不如' occurs where the full name '不如密多' does not; short forms are not linked automatically |
| UC-3447d4a663b2 | 28 菩提達磨 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |
| UC-40deafd7001a | 29 慧可 | short_or_variant_name | '達磨' occurs where the full name '菩提達磨' does not; short forms are not linked automatically |
| UC-6bff972a2c6e | 30 僧璨 | pronoun_or_context | transmission verb with no named giver or receiver in the clause |

Lưu ý: các trường hợp `short_or_variant_name` là gợi ý khớp chuỗi con. Nhiều trường hợp là dương tính giả. Chúng cần rà soát, không được xem là bằng chứng liên kết.
