# Luật trích v0.2 (PTDA-X86-LIN, phiên bản 0.2.0)

Phạm vi: mục 三十三祖世系圖 của X86n1601. 34 mục, chỉ số 0–33.

## Nguyên tắc chung

1. Chỉ tạo cạnh khi một câu trong chính văn có động từ truyền pháp và vai trò được xác định bằng luật bên dưới.
2. Không dùng thứ tự danh sách, khoảng cách, thụt dòng, số đời hay tên giống nhau để gán quan hệ.
3. Tên phải khớp đầy đủ với tên mục nguồn (dòng đầu sau nhãn `note`). Tên rút gọn, dị bản chữ và đại từ không được tự nối.
4. Phủ định (未, 不, 無, 非 ngay trước động từ) không tạo cạnh; ghi `negated_transmission`.
5. Mỗi cạnh có ít nhất một chứng cứ. Nhiều chứng cứ cùng cặp được gộp vào một claim.
6. Không bỏ qua mục sau khi tìm được một cạnh (không dùng `break`). Một mục có thể cho nhiều cạnh.

## Động từ

`付囑`, `付以`, `付`, `授`, `傳法`, `傳大法要`, `受正法`, `受大法印`, `囑`.
Động từ không nằm trong danh sách (ví dụ 受戒, 出家, 示, 見) không tạo cạnh.

## Luật

| Mã | Mẫu câu | Vai trò | Chiều |
|---|---|---|---|
| R1 | Trong cùng một mệnh đề: động từ truyền pháp, rồi đến tên đầy đủ của mục khác. Ví dụ 「後付阿難」 | Mục hiện tại trao cho tên đó | `subject_to_object` |
| R2 | 「從X出家付法」: tên X đứng trước động từ, có 從 | X trao cho mục hiện tại | `subject_to_object` |
| R3 | Mệnh đề trước có 遇X / 得X / 因X (tên đầy đủ), mệnh đề sau có động từ truyền pháp không nêu người nhận. Hoặc 得X付… trong cùng mệnh đề | Mục hiện tại trao cho X | `subject_to_object` |
| R4 | Tên đầy đủ đứng trước động từ, không có 從/遇/得, động từ không có người nhận rõ | Tên đó trao cho mục hiện tại | `subject_to_object` |

Khi R4 cho chiều ngược với thứ tự danh sách, claim được gắn cờ `text_direction_differs_from_list_order`. Cờ này không đổi chiều.

## Không tạo cạnh (ghi vào unresolvedCases)

| Loại | Ý nghĩa |
|---|---|
| `negated_transmission` | Có phủ định ngay trước động từ |
| `pronoun_or_context` | Động từ có mặt nhưng giver/receiver là đại từ (之) hoặc cần ngữ cảnh |
| `short_or_variant_name` | Dạng rút gọn hoặc dị bản của tên trong danh sách (xem lưu ý dưới) |
| `role_unclear` | Có tên nhưng không xác định được vai trò theo luật |
| `object_not_in_source_list` | Động từ 囑 có đối tượng không thuộc danh sách |

**Lưu ý về `short_or_variant_name`:** đây là gợi ý rà soát do khớp chuỗi con. Nhiều gợi ý là dương tính giả, ví dụ "多迦" nằm trong "羅睺羅多迦毗羅". Chúng không tạo cạnh và không được xem là bằng chứng.

## Giới hạn đã biết

- Đại từ không được giải quyết (claim 12→13 của v0.1 rơi vào trường hợp này).
- Mẫu 「得X付法」 đọc được theo hai cách. Luật chọn cách đọc mục hiện tại trao cho X; cần QA đối chiếu.
- Tên trong các mệnh đề không liền kề (ví dụ 難提尊者 ở mục 9) không được liên kết với 佛陀難提 nếu không có dạng đầy đủ trong câu.
- Thọ giới, thế độ, đệ tử (為弟子) không được xử lý thành loại quan hệ riêng. Chúng nằm trong unresolved hoặc bị bỏ qua. Không có claim thuộc loại thọ giới hay học tập trong v0.2.
- Không xử lý sơ đồ hoặc bảng. Mục này là danh sách văn bản, không có cấu trúc bảng hay sơ đồ được mã hóa.
